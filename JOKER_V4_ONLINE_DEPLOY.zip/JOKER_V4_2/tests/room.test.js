import test from 'node:test';
import assert from 'node:assert/strict';
import { GameRoom } from '../worker/index.js';

function makeRoom() {
  const storageMap = new Map();
  const state = {
    storage: {
      async get(k) { return storageMap.get(k); },
      async put(k, v) { storageMap.set(k, structuredClone(v)); }
    },
    blockConcurrencyWhile(fn) { return fn(); }
  };
  const room = new GameRoom(state, {});
  return room;
}
function fakeSocket() { return { sent: [], closed: false, send(v) { this.sent.push(JSON.parse(v)); }, close() { this.closed = true; } }; }

test('room accepts four seats and fixes teams by opposite seats', async () => {
  const room = makeRoom(); await room.ready;
  for (let i=0;i<4;i++) await room.join(`s${i}`, fakeSocket(), {type:i===0?'CREATE':'JOIN',code:'ABC123',name:`P${i+1}`});
  assert.equal(room.room.players.length,4);
  assert.deepEqual(room.room.players.map(p=>p.seat%2),[0,1,0,1]);
  assert.equal(room.room.hostId,room.room.players[0].id);
});

test('room reconnect token restores the same seat instead of creating a fifth player', async () => {
  const room=makeRoom(); await room.ready;
  const first=fakeSocket(); await room.join('old-session',first,{type:'CREATE',code:'ABC123',name:'Host'});
  const p=room.room.players[0], token=p.reconnectToken;
  const resumed=fakeSocket(); await room.join('new-session',resumed,{type:'JOIN',code:'ABC123',name:'Host',playerToken:token});
  assert.equal(room.room.players.length,1);
  assert.equal(p.sessionId,'new-session');
  assert.equal(p.connected,true);
  assert.equal(resumed.sent[0].type,'WELCOME');
  assert.equal(resumed.sent[0].seat,0);
});

test('public room view contains only the requesting player hand', async () => {
  const room=makeRoom(); await room.ready;
  for(let i=0;i<4;i++) await room.join(`s${i}`,fakeSocket(),{type:i===0?'CREATE':'JOIN',code:'ABC123',name:`P${i}`});
  room.room.game={round:1,turn:0,dealerIndex:0,farsh:[],piles:[[],[],[],[]],hands:[[{id:'private-0',rank:'A'}],[{id:'private-1',rank:'K'}],[{id:'private-2',rank:'Q'}],[{id:'private-3',rank:'J'}]],turnCount:0,cycleComplete:false,cumulativeScores:[0,0],dossaPending:null};
  const v=room.view(room.room.players[0].id);
  assert.deepEqual(v.game.hand.map(c=>c.id),['private-0']);
  assert.equal(JSON.stringify(v).includes('private-1'),false);
  assert.equal(JSON.stringify(v).includes('private-2'),false);
  assert.equal(JSON.stringify(v).includes('private-3'),false);
});

test('only room creator may start and start requires all four players', async () => {
  const room=makeRoom(); await room.ready;
  await room.join('s0',fakeSocket(),{type:'CREATE',code:'ABC123',name:'Host'});
  await room.start(room.room.players[0]);
  assert.equal(room.room.started,false);
  assert.equal(room.room.players.length,1);
  for(let i=1;i<4;i++) await room.join(`s${i}`,fakeSocket(),{type:'JOIN',code:'ABC123',name:`P${i}`});
  await assert.rejects(()=>room.start(room.room.players[1]),/منشئ الغرفة/);
  await room.start(room.room.players[0]);
  assert.equal(room.room.phase,'cut');
  assert.equal(room.room.started,true);
});

test('invalid room code is rejected', async()=>{
  const room=makeRoom(); await room.ready;
  const ws=fakeSocket(); await room.join('s0',ws,{type:'CREATE',code:'bad',name:'X'});
  assert.equal(ws.sent.at(-1).type,'ERROR');
  assert.equal(room.room.players.length,0);
});


test('dossa pending metadata is private to the player who must decide', async()=>{
  const room=makeRoom(); await room.ready;
  for(let i=0;i<4;i++) await room.join(`s${i}`,fakeSocket(),{type:i===0?'CREATE':'JOIN',code:'ABC123',name:`P${i}`});
  room.room.game={round:1,turn:0,dealerIndex:0,farsh:[],piles:[[],[],[],[]],hands:[[],[],[],[]],turnCount:0,cycleComplete:false,cumulativeScores:[0,0],dossaPending:{playerId:room.room.players[0].id,cardId:'hidden-card-id'}};
  const own=room.view(room.room.players[0].id), other=room.view(room.room.players[1].id);
  assert.equal(own.game.myDossaPending,true);
  assert.equal(other.game.myDossaPending,false);
  assert.equal(other.game.dossaPending,true);
  assert.equal(JSON.stringify(other).includes('hidden-card-id'),false);
  assert.equal(JSON.stringify(other).includes('playerId'),false);
});
