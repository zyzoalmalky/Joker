import test from 'node:test';
import assert from 'node:assert/strict';
import worker from '../worker/index.js';

test('single Worker serves health endpoint', async () => {
  const res = await worker.fetch(new Request('https://joker.example/health'), {});
  assert.equal(res.status, 200);
  assert.deepEqual(await res.json(), { ok: true, service: 'JOKER V4.3' });
});

test('single Worker falls back to bundled static assets for the game UI', async () => {
  let requested = '';
  const env = { ASSETS: { async fetch(request) { requested = new URL(request.url).pathname; return new Response('<h1>JOKER</h1>', { headers: { 'content-type': 'text/html' } }); } } };
  const res = await worker.fetch(new Request('https://joker.example/'), env);
  assert.equal(res.status, 200);
  assert.equal(requested, '/');
  assert.match(await res.text(), /JOKER/);
});
