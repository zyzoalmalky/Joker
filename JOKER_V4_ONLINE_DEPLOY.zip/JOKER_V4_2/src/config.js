// يعمل التطبيق والـ WebSocket على نفس رابط Worker بعد النشر.
export const SERVER_URL = window.location.origin;
