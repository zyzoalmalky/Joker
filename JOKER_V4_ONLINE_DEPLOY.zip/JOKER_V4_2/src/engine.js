export const RANKS = ["A","2","3","4","5","6","7","8","9","10","J","Q","K"];
export const ROUND_HAND_SIZES = [8, 9, 9];
export const TARGET_SCORE = 310;
const uid = () => globalThis.crypto?.randomUUID?.() ?? `c-${Math.random().toString(36).slice(2)}-${Date.now()}`;

export function makeDeck() {
  const cards=[];
  for (const rank of RANKS) for(let i=0;i<8;i++) cards.push({id:uid(),rank,joker:false});
  cards.push({id:uid(),rank:"JOKER",joker:true},{id:uid(),rank:"JOKER",joker:true});
  return cards;
}
export function shuffle(input, random=Math.random) {
  const a=[...input]; for(let i=a.length-1;i>0;i--){const j=Math.floor(random()*(i+1));[a[i],a[j]]=[a[j],a[i]];} return a;
}
export function teamOf(playerIndex){ if(!Number.isInteger(playerIndex)||playerIndex<0||playerIndex>3) throw Error("رقم اللاعب غير صحيح."); return playerIndex%2===0?0:1; }
export function cardPoints(c){return c.joker||c.rank==="JOKER"?25:c.rank==="J"?2:1;}

// ورقتان للفرش و104 موزعة على 4 لاعبين، لكن تفتح على دفعات 8/9/9.
export function cutAndDeal({deck=makeDeck(),dealerIndex=0,random=Math.random,cutAt=0}={}){
  if(deck.length!==106) throw Error("الدستة لازم تكون 106 ورقات.");
  if(new Set(deck.map(c=>c.id)).size!==106) throw Error("يوجد معرّف ورقة مكرر في الدستة.");
  if(!Number.isInteger(dealerIndex)||dealerIndex<0||dealerIndex>3) throw Error("الموزع غير صحيح.");
  const mixed=shuffle(deck,random);
  if(!Number.isInteger(cutAt)||cutAt<0||cutAt>=106) throw Error("موضع القص غير صحيح.");
  const cutDeck=[...mixed.slice(cutAt),...mixed.slice(0,cutAt)];
  const farsh=cutDeck.slice(0,2), stock=cutDeck.slice(2);
  // احتفظ بتسلسل التوزيع حسب الجولات مع مراعاة اللاعب الذي يبدأ بعد الموزع.
  const roundCards=[[],[],[],[]]; let cursor=0;
  for(const count of ROUND_HAND_SIZES) for(let n=0;n<count;n++) for(let off=0;off<4;off++) roundCards[(dealerIndex+1+off)%4].push(stock[cursor++]);
  const active=roundCards.map(a=>a.slice(0,8));
  const queued=roundCards.map(a=>[a.slice(8,17),a.slice(17,26)]);
  return {farsh, hands:active, queued, totalDealt:104, remainingStock:0};
}
export function hasTarget(rank,playerIndex,piles,farsh){
  return farsh.some(c=>c.rank===rank)||piles.some((pile,owner)=>owner!==playerIndex&&pile.some(c=>c.rank===rank));
}
export function getCapturableRanks(playerIndex,hand,piles,farsh){
  const out=new Set();
  for(const c of hand){ if(c.joker){ for(const f of farsh) if(!f.joker) out.add(f.rank); piles.forEach((p,o)=>{if(o!==playerIndex)p.forEach(x=>{if(!x.joker)out.add(x.rank);});}); if(farsh.some(f=>f.joker)) RANKS.forEach(r=>out.add(r)); }
    else if(hasTarget(c.rank,playerIndex,piles,farsh)) out.add(c.rank); }
  return [...out];
}
export function resolvePlay({cardId,chosenRank=null,playerIndex,hand,piles,farsh}){
  if(!Array.isArray(piles)||piles.length!==4) throw Error("حالة المكاسب غير صحيحة.");
  const ix=hand.findIndex(c=>c.id===cardId); if(ix<0) throw Error("الورقة دي مش في إيدك.");
  const played=hand[ix]; if(played.joker&&(!RANKS.includes(chosenRank))) throw Error("اختار رتبة صحيحة للجوكر.");
  const rank=played.joker?chosenRank:played.rank, nextHand=hand.filter((_,i)=>i!==ix), nextPiles=piles.map(p=>[...p]); let nextFarsh=[...farsh]; const captured=[];
  for(let owner=0;owner<4;owner++) if(owner!==playerIndex){const hits=nextPiles[owner].filter(c=>c.rank===rank);captured.push(...hits);nextPiles[owner]=nextPiles[owner].filter(c=>c.rank!==rank);}
  const hits=nextFarsh.filter(c=>c.rank===rank||(played.joker&&c.joker));captured.push(...hits);nextFarsh=nextFarsh.filter(c=>!(c.rank===rank||(played.joker&&c.joker)));
  if(captured.length) nextPiles[playerIndex].push(played,...captured); else nextFarsh.push(played);
  return {hand:nextHand,piles:nextPiles,farsh:nextFarsh,captured:captured.length>0,capturedCount:captured.length,playedCard:played,targetRank:rank};
}
// الدوسة: لعب ورقة لا تلتقط بينما توجد ورقة أخرى قانونية تلتقط.
export function dossaWouldOccur({cardId,playerIndex,hand,piles,farsh}){
  const chosen=hand.find(c=>c.id===cardId); if(!chosen) throw Error("الورقة دي مش في إيدك.");
  const alternatives=hand.filter(c=>c.id!==cardId);
  return alternatives.some(c=>c.joker ? getCapturableRanks(playerIndex,[c],piles,farsh).length>0 : hasTarget(c.rank,playerIndex,piles,farsh));
}
export function resolveDossa({cardId,playerIndex,hand,piles,farsh,confirm=false}){
  if(!dossaWouldOccur({cardId,playerIndex,hand,piles,farsh})) throw Error("مفيش دوسة: مفيش ورقة أخرى متاحة للأخذ.");
  if(!confirm) return {warning:true,message:"عندك ورقة تقدر تاخد بيها. تقدر ترجع وتصحح أو تؤكد الدوسة."};
  const card=hand.find(c=>c.id===cardId), nextHand=hand.filter(c=>c.id!==cardId), nextPiles=piles.map(p=>[...p]);
  const opposingTeam=1-teamOf(playerIndex), recipient=opposingTeam; // اللاعب 1 أو 2 من الفريق المنافس يستقبل ورقة الجزاء
  nextPiles[recipient].push(card);
  const penalties=[0,0]; penalties[opposingTeam]=25;
  return {warning:false,hand:nextHand,piles:nextPiles,farsh:[...farsh],penaltyTeam:opposingTeam,penaltyPoints:25,penaltyCardId:cardId,penalties};
}
export function scoreCycle(piles,dossaPenalties=[0,0],cumulative=[0,0]){
  const round=[0,0]; piles.forEach((pile,p)=>round[teamOf(p)]+=pile.reduce((s,c)=>s+cardPoints(c),0));
  round[0]+=dossaPenalties[0]||0;round[1]+=dossaPenalties[1]||0;
  const scores=[cumulative[0]+round[0],cumulative[1]+round[1]];
  return {roundScores:round,scores,winner:scores[0]>=TARGET_SCORE?0:scores[1]>=TARGET_SCORE?1:null};
}
export function createCycleState({dealerIndex=0,deck,random,cutAt=0}={}){
  const d=cutAndDeal({deck:deck||makeDeck(),dealerIndex,random,cutAt});
  return {dealerIndex,round:1,turn:(dealerIndex+1)%4,hands:d.hands,queued:d.queued,farsh:d.farsh,piles:[[],[],[],[]],dossaPenalties:[0,0],cumulativeScores:[0,0],cycleComplete:false,turnCount:0};
}
export function nextTurnIndex(state,from=state.turn){for(let step=1;step<=4;step++){const p=(from+step)%4;if(state.hands[p].length>0)return p;}return -1;}
export function advanceAfterPlay(state){
  const next={...state,hands:state.hands.map(h=>[...h]),queued:state.queued.map(q=>q.map(r=>[...r])),piles:state.piles.map(p=>[...p]),farsh:[...state.farsh],dossaPenalties:[...state.dossaPenalties],cumulativeScores:[...state.cumulativeScores]};
  if(next.hands.every(h=>h.length===0)){
    if(next.round<3){next.round++;next.hands=next.queued.map(q=>q.shift()||[]);next.turn=(next.dealerIndex+1)%4;return {state:next,roundStarted:true,cycleEnded:false};}
    const scored=scoreCycle(next.piles,next.dossaPenalties,next.cumulativeScores);next.cumulativeScores=scored.scores;next.cycleComplete=true;next.finalScore=scored;return {state:next,roundStarted:false,cycleEnded:true};
  }
  next.turn=nextTurnIndex(next,next.turn); return {state:next,roundStarted:false,cycleEnded:false};
}
export function auditCards(state){
  const all=[...state.farsh,...state.hands.flat(),...state.queued.flat(2),...state.piles.flat()];
  const ids=all.map(c=>c.id);return {count:all.length,unique: new Set(ids).size,duplicates:ids.length-new Set(ids).size,valid:all.length===106&&new Set(ids).size===106};
}
